const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
const secreteKey = 'screteKey';

app.get("/", (erq, resp) => {
    resp.json({
        message: "thsi is a simple"
    })
});

app.post("/login", (erq, resp) => {
    const user = {
        id: 1,
        username: "singh",
        email: "abc@test.com"

    }
    jwt.sign({ user }, secreteKey, { expiresIn: '300s' }, (err, token) => {
        resp.json({token})

    })
})
app.post("/profile",veryfyToken,(req,resp)=>{

})
function veryfyToken(req,resp,next){
    const bearerHeader=req.headers['authorization']
    if (typeof bearerHeader !=='undefined'){

    }else
    resp.send({result:'Token is not valid'})

}



app.listen(5000, () => {
    console.log('app is runnig is 5000 port')
})



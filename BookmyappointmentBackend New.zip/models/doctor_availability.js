const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
mongoose.connect('mongodb://127.0.0.1:27017/book_my_appointment', { useNewUrlParser: true, useUnifiedTopology: true });
const Doc_avaibleSchema = new mongoose.Schema({

    Date: { type: String, require: true },
    No_of_pasent: { type:Number, require: true },
    First_half_time: { type: String, require: true },
    Second_half_time: { type: String, require: true },

},{timestamps:true}
);
module.exports = mongoose.model('Doctor_availability', Doc_avaibleSchema);
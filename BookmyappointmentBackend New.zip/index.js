const express = require('express');
const nodemailer = require("nodemailer")
require('./models/mongo_config');
const User = require('./models/user_models');
const user_appointment = require('./models/user_appointment');
const Doctor = require('./models/doctor_models');
const Doctor_profiles = require('./models/doctor_profiles');
const Doctor_availability=require('./models/doctor_availability')
const jwt = require('jsonwebtoken');
const secretKey = 'your-secret-key';
const app = express();
app.use(express.json());
const cors = require('cors');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const port = process.env.PORT || 3000;
const bodyParser = require('body-parser');

// Configure body-parser to handle JSON data
app.use(bodyParser.json());
// Recieved Data From CrossHeader...........................
const corsOptions = {
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200, // Some legacy browsers (IE11, various SmartTVs) choke on 204
};
app.use(cors(corsOptions));

// Registration API Here For User Registration...............

app.post('/register', async (req, res) => {
  const { Phone_Number, Password } = req.body;

  try {
    // Check if the username already exists in the database
    const existingUser = await User.findOne({ Phone_Number });

    if (existingUser) {
      return res.status(409).json({ message: 'Username already exists' });
    }
    // Create a new user document
    const newUser = new User(req.body);
    // Save the user to the database
    await newUser.save();

    res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Registration failed' });
  }
});
// Here Registration API is Completed.......................

//Login API Heare for User Login.............................
app.post('/login', async (req, res) => {

  const { Phone_Number, Password } = req.body;
  try {

    const user = await User.findOne({ Phone_Number });


    if (!user) {
      return res.status(200).json('Worng_Phone_no!!');
    }

    const passwordMatch = await bcrypt.compare(Password, user.Password);

    if (!passwordMatch) {
      return res.status(200).json('Worng_password!!');
    }

    const token = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '1h' });

    res.status(200).json({message:"success",name : `${user.First_name}`,user_details:`${User._id}`});
  } catch (error) {
    console.error('Error during login', error);
    res.status(500).json({ error: 'Login failed' });
  }
});
// Login Api is Completed ......................................................|

//Forget Password Api is Here...................................................|
// Configure Nodemailer for sending emails (use your SMTP server)
const transporter = nodemailer.createTransport({
  service: 'Gmail',
  auth: {
    user: 'bookmyappointment.io@gmail.com',
    pass: 'twvabwjjcyamnrqw'
  }
});
// In-memory storage for password reset tokens (You should use a database in production)
const passwordResetTokens = new Map();
// Generate a random token
function generateToken() {
  return crypto.randomBytes(20).toString('hex');
}
// Send password reset email
app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  try {
    const Existingmail = await User.findOne({ email });

    if (!Existingmail) {
      return res.status(200).json({ message: 'Email address is not Register Please Register First.' });
    }

    // Generate a unique token for this user
    const token = generateToken();

    // Store the token (you should use a database in production)
    passwordResetTokens.set(email, token);

    // Send a password reset email to the user
    const mailOptions = {
      from: 'bookmyappointment.io@gmail.com',
      to: email,
      subject: 'Password Reset',
      text: `Click the following link to reset your password: http://localhost:${port}/reset-password`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        res.status(500).json({ message: 'Failed to send password reset email.' });
      } else {
        res.json({ message: 'Password reset email sent.' });
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Please Try after some time' });

  }
});
//...........................................................................................
//Code ending ....with_User.....Register....Login.....Forget-Password....is Completed........
//...........................................................................................
// Registration API Here For Doctor Registration.............................................

app.post('/register-doc', async (req, res) => {
  const { Phone_Number, Password } = req.body;

  try {
    // Check if the doctor already exists in the database
    const existingUser = await Doctor.findOne({ Phone_Number });

    if (existingUser) {
      return res.status(409).json({ message: 'Doctor already exists' });
    }
    // Create a new userdoctor document
    const newdoc = new Doctor(req.body);
    // Save the doctor to the database
    await newdoc.save();

    res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Registration failed' });
  }
});
// Here Registration API is Completed.......................
//Login API Heare for User Login.............................
app.post('/login-doc', async (req, res) => {

  const { Phone_Number, Password } = req.body;
  try {

    const user = await Doctor.findOne({ Phone_Number });


    if (!user) {
      return res.status(200).json('Worng_Phone_no!!');
    }

    const passwordMatch = await bcrypt.compare(Password, user.Password);

    if (!passwordMatch) {
      return res.status(200).json('Worng_password!!');
    }

    const token = jwt.sign({ userId: user._id }, 'your-secret-key', { expiresIn: '1h' });

    res.status(200).json({message:"success", name : `${user.Doctor_name}`,user_details:`${Doctor._id}`});
  } catch (error) {
    console.error('Error during login', error);
    res.status(500).json({ error: 'Login failed' });
  }
});
// Login Api is Completed ......................................................|

// Doctor Forget Password Api is Here...................................................|

app.post('/forgot-password-doc', async (req, res) => {
  const { email } = req.body;

  try {
    const Existingmail = await Doctor.findOne({ email });
  

    if (!Existingmail) {
       res.status(201).json({ message: 'Email address is not Register Please Register First.' });
    }

    // Generate a unique token for this user
    const token = generateToken();

    // Store the token (you should use a database in production)
    passwordResetTokens.set(email, token);

    // Send a password reset email to the user
    const mailOptions = {
      from: 'bookmyappointment.io@gmail.com',
      to: email,
      subject: 'Password Reset',
      text: `Click the following link to reset your password: http://localhost:${port}/reset-password/${token}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        res.status(500).json({ message: 'Failed to send password reset email.' });
      } else {
        res.json({ message: 'Password reset email sent.' });
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Please Try after some time' });

  }
});
//...........................................................................................
//Code ending ....with_Doctor.....Register....Login.....Forget-Password....is Completed......
//...........................................................................................

// Doctor_Profile Subbmit Api................................................................
app.post('/doctor-profile', async (req, res) => {
    const newdoc_profile = new Doctor_profiles(req.body);
    await newdoc_profile.save();
    res.status(201).json({ message: 'Profile_successfully_save!!' });
});
// Doctor_availability Subbmit Api................................................................
app.post('/doctor-present', async (req, res) => {
  const doc_availability = new Doctor_availability(req.body);
  await doc_availability.save();
  res.status(201).json({ message: 'data and time save !!' });
});
// Fetch All Data Of Doctor..................................................................
app.get('/fetch_all_doctor', async (req, res) => {
  Doctor_profiles.find().then((result)=>{
    
    res.send(result)
  }).catch((err)=>{
    console.log(err)
  }); 
});
// Fetch All Data Of doc_availability..................................................................
app.get('/fetch_avaible', async (req, res) => {
  doc_availability.find().then((result)=>{
    res.send(result)
  }).catch((err)=>{
    console.log(err)
  }); 
});
// Fetch All Data Of Doctor......is Completed................................................
//...........................................................................................
//............................User Appoientment Booking Api Start Here.......................
//...........................................................................................

app.post('/user_appointment', async (req, res) => {
  const new_user_appointment = new user_appointment(req.body);
  await new_user_appointment.save();
  res.status(201).json({ message: 'your appoientment is book!!' });
});
// Define a route to fetch a single Doctore by ID
app.get('/docprofile/:id', async (req, res) => {
  try {
    // const doc = await Doctor_profiles.findById(req.query.uid);
        const doc = await Doctor_profiles.findById(req.params.id);
    // console.log("123",req.params.id)
    if (!doc) {
      return res.status(404).json({ message: 'doctor not found' });
    }
    res.json(doc);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.listen(5000, () => {
  console.log('app is runnig is 5000 port')

});